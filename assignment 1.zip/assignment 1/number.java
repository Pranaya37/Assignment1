public class number{
static void convert_to_words(char[] num)
{
int len=num.length;
if(len==0)
{
System.out.print("empty string");
return;
}
if(len>4)
{
System.out.print("length more than 4 is not supported");
return;
}
String[] single_digits=new String[]
{"zero","one","two","three","four","five","six","seven","eight","nine"};
String[] two_digits=new String[]
{"ten","eleven","twelve","thirteen","fourteen","fivteen","sixteen","seventeen","eighteen","nineteen"};
String[] tens_multiple=new String[]
{"","","twenty","thirty","forty","fifty","sixty","seventy","eighty","ninty"};
String[] tens_power=new String[]
{"hundred","thousand"};
System.out.println(String.valueOf(num)+ " ; ");
if(len==1)
{
System.out.println(single_digits[num[0]- '0']);
return;
}
int x=0;
while(x<num.length)
{
if(len>=3)
{
if(num[x]- '0'!=0)
{
System.out.print(single_digits[num[x]-'0']+" ");
System.out.print(tens_power[len -3] + " ");
}
--len;
}
else{
if(num[x]-'0'==1)
{
int sum=num[x]-'0'+num[x+1]-'0';
System.out.print(two_digits[sum]);
return;
}
else if(num[x]-'0'==2 && num[x+1]-'0'==0)
{
System.out.print("twenty");
return;
}
else
{
int i=(num[x]-'0');
if(i>0)
System.out.print(tens_multiple[i]+ " ");
else
System.out.print(" ");
++x;
if(num[x]-'0'!=0)
System.out.print(single_digits[num[x]- '0']);
}
}
++x;
}
}
public static void main(String[] args)
{
convert_to_words("9999".toCharArray());
convert_to_words("576".toCharArray());
convert_to_words("59".toCharArray());
convert_to_words("5".toCharArray());
}
}